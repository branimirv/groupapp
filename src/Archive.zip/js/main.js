// Import SCSS
import "../scss/main.scss";

// Import Slick Slider
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel";

console.log("Main JavaScript loaded");

// Mobile menu functionality
document.addEventListener("DOMContentLoaded", function () {
  const menuToggle = document.querySelector(".menu-btn.toggle");
  const mobileMenu = document.querySelector(".header-menu.links");
  const body = document.body;

  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener("click", function () {
      menuToggle.classList.toggle("active");
      mobileMenu.classList.toggle("active");

      // Prevent body scroll when mobile menu is open
      if (mobileMenu.classList.contains("active")) {
        body.style.overflow = "hidden";
      } else {
        body.style.overflow = "";
      }
    });

    // Close mobile menu when clicking on menu links
    const menuLinks = mobileMenu.querySelectorAll("a");
    menuLinks.forEach((link) => {
      link.addEventListener("click", function () {
        menuToggle.classList.remove("active");
        mobileMenu.classList.remove("active");
        body.style.overflow = "";
      });
    });

    // Close mobile menu when clicking outside
    document.addEventListener("click", function (event) {
      if (
        !menuToggle.contains(event.target) &&
        !mobileMenu.contains(event.target)
      ) {
        menuToggle.classList.remove("active");
        mobileMenu.classList.remove("active");
        body.style.overflow = "";
      }
    });
  }
});

// // Initialize Slick Slider
// document.addEventListener("DOMContentLoaded", function () {
//   // Initialize slick sliders
//   initSlickSliders();
// });

// Initialize Creators Slider
document.addEventListener("DOMContentLoaded", function () {
  initCreatorsSlider();
});

// Initialize Community and Automations Sliders
document.addEventListener("DOMContentLoaded", function () {
  initCommunityAndAutomationsSliders();
});

// Initialize Comments Slider (Home Page)
document.addEventListener("DOMContentLoaded", function () {
  initCommentsSlider();
});

function initCreatorsSlider() {
  const creatorsGallery = document.querySelector(".creators__gallery");

  if (creatorsGallery && window.innerWidth <= 992) {
    // Count total slides to determine initial slide
    const totalSlides = $(creatorsGallery).find("> div").length;
    const initialSlide = Math.max(1, Math.floor(totalSlides / 2)); // Start from middle or at least slide 1

    // Initialize slick slider on mobile
    $(creatorsGallery).slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      dots: false,
      infinite: true,
      centerMode: true,
      centerPadding: "25%",
      variableWidth: false,
      autoplay: true,
      autoplaySpeed: 3000,
      focusOnSelect: true,
      initialSlide: initialSlide,
      responsive: [
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            centerMode: true,
            centerPadding: "20%",
            initialSlide: initialSlide,
          },
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1,
            centerMode: true,
            centerPadding: "15%",
            initialSlide: initialSlide,
            variableWidth: true,
          },
        },
      ],
    });
  }

  // Handle window resize
  let resizeTimer;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      if (window.innerWidth <= 992) {
        // Initialize slider if not already initialized
        if (!$(creatorsGallery).hasClass("slick-initialized")) {
          const totalSlides = $(creatorsGallery).find("> div").length;
          const initialSlide = Math.max(1, Math.floor(totalSlides / 2));

          $(creatorsGallery).slick({
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            dots: false,
            infinite: true,
            centerMode: true,
            centerPadding: "25%",
            variableWidth: false,
            autoplay: true,
            autoplaySpeed: 3000,
            focusOnSelect: true,
            initialSlide: initialSlide,
            responsive: [
              {
                breakpoint: 768,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  centerMode: true,
                  centerPadding: "20%",
                  initialSlide: initialSlide,
                },
              },
              {
                breakpoint: 480,
                settings: {
                  slidesToShow: 1,
                  slidesToScroll: 1,
                  centerMode: true,
                  centerPadding: "15%",
                  initialSlide: initialSlide,
                },
              },
            ],
          });
        }
      } else {
        // Destroy slider on desktop
        if ($(creatorsGallery).hasClass("slick-initialized")) {
          $(creatorsGallery).slick("unslick");
        }
      }
    }, 250);
  });
}

function initCommunityAndAutomationsSliders() {
  const communitySliders = document.querySelectorAll(".community-items-slider");
  const automationsSliders = document.querySelectorAll(
    ".automations-items-slider"
  );

  // Combine both slider types
  const allSliders = [...communitySliders, ...automationsSliders];

  function initializeSlider(slider) {
    if (slider && window.innerWidth <= 992) {
      // Check if slider is already initialized
      if ($(slider).hasClass("slick-initialized")) {
        $(slider).slick("unslick");
      }

      // Initialize slick slider on mobile
      $(slider).slick({
        slidesToShow: 1.3,
        slidesToScroll: 1,
        arrows: false,
        dots: true,
        infinite: false,
        centerMode: false,
        variableWidth: false,
        adaptiveHeight: false,
        autoplay: false,
        focusOnSelect: true,
        initialSlide: 0,
        responsive: [
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 1.2,
              slidesToScroll: 1,
              centerMode: false,
              variableWidth: false,
              infinite: false,
              adaptiveHeight: false,
              initialSlide: 0,
              dots: true,
            },
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1.1,
              slidesToScroll: 1,
              centerMode: false,
              variableWidth: false,
              infinite: false,
              adaptiveHeight: false,
              initialSlide: 0,
              dots: true,
            },
          },
        ],
      });
    } else {
      // Destroy slider on desktop
      if ($(slider).hasClass("slick-initialized")) {
        $(slider).slick("unslick");
      }
    }
  }

  // Make initializeSlider available globally
  window.initializeSlider = initializeSlider;

  // Initialize all sliders
  allSliders.forEach((slider) => {
    initializeSlider(slider);
  });

  // Initialize sliders for active tabs on page load
  setTimeout(() => {
    const communityContainer = document.querySelector(".community");
    const automationsContainer = document.querySelector(".automations");

    if (communityContainer) {
      reinitializeActiveSliders(communityContainer);
    }

    if (automationsContainer) {
      reinitializeActiveSliders(automationsContainer);
    }
  }, 100);

  // Function to reinitialize sliders in active tab
  function reinitializeActiveSliders(container) {
    if (
      container.classList.contains("community") ||
      container.classList.contains("automations")
    ) {
      // Small delay to ensure tab content is visible before initializing slider
      setTimeout(() => {
        const activeTab = container.querySelector(".tab-content .tab.active");
        if (activeTab) {
          const slider = activeTab.querySelector(
            ".community-items-slider, .automations-items-slider"
          );
          if (slider) {
            initializeSlider(slider);
          }
        }
      }, 150);
    }
  }

  // Make this function available globally so it can be called from tab switching
  window.reinitializeActiveSliders = reinitializeActiveSliders;

  // Handle window resize
  let resizeTimer;
  window.addEventListener("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      allSliders.forEach((slider) => {
        initializeSlider(slider);
      });
    }, 250);
  });
}

// Initialize Comments Slider
function initCommentsSlider() {
  const $carousel = $(".sliderComments");

  if (!$carousel.length) return; // Exit if slider doesn't exist

  function initializeSlider() {
    if (!$carousel.hasClass("slick-initialized")) {
      $carousel.slick({
        slidesToScroll: 1,
        variableWidth: true,
        prevArrow: $(".slick-slider__buttonPrev"),
        nextArrow: $(".slick-slider__buttonNext"),
        centerMode: true,
        initialSlide: 3,
        infinite: false,
        arrows: true,
        dots: false,
        responsive: [
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 1.2,
              slidesToScroll: 1,
              centerMode: false,
              variableWidth: false,
              initialSlide: 0,
              arrows: true,
              infinite: false,
            },
          },
          {
            breakpoint: 768,
            settings: {
              slidesToShow: 1.1,
              slidesToScroll: 1,
              centerMode: false,
              variableWidth: false,
              initialSlide: 0,
              arrows: true,
              infinite: false,
            },
          },
        ],
      });
    }
  }

  // Initialize on page load
  initializeSlider();

  // Handle window resize
  let resizeTimer;
  $(window).on("resize", function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      if ($carousel.hasClass("slick-initialized")) {
        $carousel.slick("unslick");
      }
      initializeSlider();
    }, 300);
  });
}

// Universal tab functionality with draggable support for all sections
document.addEventListener("DOMContentLoaded", function () {
  // Initialize all tab containers on the page - supporting multiple section types
  const tabContainers = document.querySelectorAll(
    ".community, .lms, .automations, .membership, .branding-and-customization"
  );

  tabContainers.forEach((container) => {
    const tabLinks = container.querySelectorAll(".tabs a");
    const tabsContainer = container.querySelector(".tabs");

    // Different sections have different content selectors
    let tabContent;
    if (
      container.classList.contains("lms") ||
      container.classList.contains("membership") ||
      container.classList.contains("branding-and-customization")
    ) {
      // For LMS, membership, and branding sections, tabs are in .lms__tab-panels
      tabContent = container.querySelectorAll(".lms__tab-panels .tab");
    } else {
      // For community and automations sections, tabs are in .tab-content
      tabContent = container.querySelectorAll(".tab-content .tab");
    }

    // Function to scroll active tab into view
    function scrollActiveTabIntoView() {
      if (window.innerWidth <= 992) {
        const activeTab = container.querySelector(".tabs li.active");
        if (activeTab) {
          const containerRect = tabsContainer.getBoundingClientRect();
          const tabRect = activeTab.getBoundingClientRect();
          const scrollLeft = tabsContainer.scrollLeft;

          // Calculate if tab is outside visible area
          const tabLeftRelative = tabRect.left - containerRect.left;
          const tabRightRelative = tabRect.right - containerRect.right;

          if (tabLeftRelative < 0) {
            // Tab is cut off on the left
            tabsContainer.scrollLeft = scrollLeft + tabLeftRelative - 20;
          } else if (tabRightRelative > 0) {
            // Tab is cut off on the right
            tabsContainer.scrollLeft = scrollLeft + tabRightRelative + 20;
          }
        }
      }
    }

    // Add click event listeners to tab links
    tabLinks.forEach((link, index) => {
      link.addEventListener("click", function (e) {
        e.preventDefault();

        // Remove active class from all tabs and content
        tabLinks.forEach((tabLink) => {
          tabLink.parentElement.classList.remove("active");
        });

        tabContent.forEach((content) => {
          content.classList.remove("active");
        });

        // Add active class to clicked tab and corresponding content
        this.parentElement.classList.add("active");

        // Get the target tab content
        const targetId = this.getAttribute("href").substring(1);
        const targetContent = container.querySelector(`#${targetId}`);

        if (targetContent) {
          targetContent.classList.add("active");
        }

        // For LMS, membership, and branding sections, also handle image switching
        if (
          container.classList.contains("lms") ||
          container.classList.contains("membership") ||
          container.classList.contains("branding-and-customization")
        ) {
          // Handle both desktop and mobile images
          const desktopImages = container.querySelectorAll(
            ".lms__images--desktop .lms__image"
          );
          const mobileImages = container.querySelectorAll(
            ".lms__images--mobile .lms__image"
          );

          // Handle payments section which has only one image container
          const paymentsImages = container.querySelectorAll(
            ".payments__images .lms__image"
          );

          // Remove active class from all images
          [...desktopImages, ...mobileImages, ...paymentsImages].forEach(
            (img) => {
              img.classList.remove("active");
            }
          );

          // Add active class to the corresponding images
          if (desktopImages[index]) {
            desktopImages[index].classList.add("active");
          }
          if (mobileImages[index]) {
            mobileImages[index].classList.add("active");
          }
          if (paymentsImages[index]) {
            paymentsImages[index].classList.add("active");
          }

          // Reinitialize accordions for the new active tab
          setTimeout(() => {
            initializeAccordionsForTab(targetContent);
          }, 50);
        }

        // Scroll active tab into view on mobile
        setTimeout(scrollActiveTabIntoView, 100);

        // Reinitialize sliders for community and automations sections
        if (
          container.classList.contains("community") ||
          container.classList.contains("automations")
        ) {
          reinitializeActiveSliders(container);
        }
      });
    });

    // Initialize draggable functionality for mobile
    if (tabsContainer) {
      let isDragging = false;
      let startX = 0;
      let scrollLeft = 0;

      // Mouse events
      tabsContainer.addEventListener("mousedown", (e) => {
        if (window.innerWidth <= 992) {
          isDragging = true;
          startX = e.pageX - tabsContainer.offsetLeft;
          scrollLeft = tabsContainer.scrollLeft;
          tabsContainer.style.cursor = "grabbing";
        }
      });

      tabsContainer.addEventListener("mouseleave", () => {
        isDragging = false;
        tabsContainer.style.cursor = "grab";
      });

      tabsContainer.addEventListener("mouseup", () => {
        isDragging = false;
        tabsContainer.style.cursor = "grab";
      });

      tabsContainer.addEventListener("mousemove", (e) => {
        if (!isDragging || window.innerWidth > 992) return;
        e.preventDefault();
        const x = e.pageX - tabsContainer.offsetLeft;
        const walk = (x - startX) * 2;
        tabsContainer.scrollLeft = scrollLeft - walk;
      });

      // Touch events
      tabsContainer.addEventListener("touchstart", (e) => {
        if (window.innerWidth <= 992) {
          isDragging = true;
          startX = e.touches[0].pageX - tabsContainer.offsetLeft;
          scrollLeft = tabsContainer.scrollLeft;
        }
      });

      tabsContainer.addEventListener("touchmove", (e) => {
        if (!isDragging || window.innerWidth > 992) return;
        const x = e.touches[0].pageX - tabsContainer.offsetLeft;
        const walk = (x - startX) * 2;
        tabsContainer.scrollLeft = scrollLeft - walk;
      });

      tabsContainer.addEventListener("touchend", () => {
        isDragging = false;
      });

      // Set cursor style on mobile
      function updateCursor() {
        if (window.innerWidth <= 992) {
          tabsContainer.style.cursor = "grab";
        } else {
          tabsContainer.style.cursor = "default";
        }
      }

      // Initial cursor setup
      updateCursor();

      // Update cursor on window resize
      window.addEventListener("resize", updateCursor);

      // Scroll active tab into view on window resize
      window.addEventListener("resize", () => {
        setTimeout(scrollActiveTabIntoView, 100);
      });
    }
  });
});

// Accordion functionality
function toggleAccordion(element) {
  const accordionItem = element.closest(".accordion-item");
  const accordionContent = accordionItem.querySelector(".accordion-content");
  const accordionSign = element.querySelector(".accordion-sign");

  // Find the accordion container - either a tab or a standalone accordion container
  const currentTab = element.closest(".tab");
  const accordionContainer =
    currentTab ||
    element.closest(".thrive-with-groupapp__content") ||
    element.closest(".tab-content__items");

  // Get all accordion items in the same container
  const allAccordionItems = accordionContainer
    ? accordionContainer.querySelectorAll(".accordion-item")
    : [];

  // Close all other accordions in the same container
  allAccordionItems.forEach((item) => {
    if (item !== accordionItem) {
      const otherContent = item.querySelector(".accordion-content");
      const otherHeader = item.querySelector(".accordion-header");
      const otherSign = item.querySelector(".accordion-sign");

      if (otherContent && otherHeader && otherSign) {
        otherContent.classList.remove("active");
        otherHeader.classList.remove("active");
        otherSign.textContent = "+";
      }
    }
  });

  // Toggle current accordion
  const isActive = accordionContent.classList.contains("active");

  if (isActive) {
    // Close current accordion
    accordionContent.classList.remove("active");
    element.classList.remove("active");
    accordionSign.textContent = "+";
  } else {
    // Open current accordion
    accordionContent.classList.add("active");
    element.classList.add("active");
    accordionSign.textContent = "-";
  }
}

// Make toggleAccordion function globally accessible
window.toggleAccordion = toggleAccordion;

// Initialize accordions on page load
document.addEventListener("DOMContentLoaded", function () {
  // Set first accordion in each tab as active by default for LMS, membership, and branding sections
  const tabPanels = document.querySelectorAll(
    ".lms__tab-panels .tab, .membership .tab, .branding-and-customization .tab"
  );

  tabPanels.forEach((tab) => {
    // Only initialize accordions for the active tab
    if (tab.classList.contains("active")) {
      const firstAccordionItem = tab.querySelector(".accordion-item");
      if (firstAccordionItem) {
        const firstHeader =
          firstAccordionItem.querySelector(".accordion-header");
        const firstContent =
          firstAccordionItem.querySelector(".accordion-content");
        const firstSign = firstAccordionItem.querySelector(".accordion-sign");

        if (firstHeader && firstContent && firstSign) {
          firstHeader.classList.add("active");
          firstContent.classList.add("active");
          firstSign.textContent = "-";
        }
      }
    }
  });

  // Set first accordion as active for standalone accordion sections (like thrive-with-groupapp)
  const standaloneAccordionContainers = document.querySelectorAll(
    ".thrive-with-groupapp__content"
  );

  standaloneAccordionContainers.forEach((container) => {
    const firstAccordionItem = container.querySelector(".accordion-item");
    if (firstAccordionItem) {
      const firstHeader = firstAccordionItem.querySelector(".accordion-header");
      const firstContent =
        firstAccordionItem.querySelector(".accordion-content");
      const firstSign = firstAccordionItem.querySelector(".accordion-sign");

      if (firstHeader && firstContent && firstSign) {
        firstHeader.classList.add("active");
        firstContent.classList.add("active");
        firstSign.textContent = "-";
      }
    }
  });
});

function initFaqAccordion() {
  // Hide all FAQ answers initially
  $(".section-faq .answer").hide();

  // Add click event to FAQ items
  $(".section-faq .accordian-item").on("click", function () {
    const $this = $(this);
    const $answer = $this.find(".answer");
    const $plusminus = $this.find(".plusminus");

    // Check if this item is currently active
    const isActive = $this.hasClass("active");

    // Close all other FAQ items
    $(".section-faq .accordian-item").removeClass("active");
    $(".section-faq .answer").slideUp(300);
    $(".section-faq .plusminus").removeClass("active");

    // If this item wasn't active, open it
    if (!isActive) {
      $this.addClass("active");
      $answer.slideDown(300);
      $plusminus.addClass("active");
    }
  });

  // Optional: Open first FAQ item by default
  $(".section-faq .accordian-item").first().addClass("active");
  $(".section-faq .accordian-item").first().find(".answer").show();
  $(".section-faq .accordian-item")
    .first()
    .find(".plusminus")
    .addClass("active");
}

// Initialize FAQ accordion on page load
initFaqAccordion();

// Initialize integrations filter draggable functionality
document.addEventListener("DOMContentLoaded", function () {
  initIntegrationsFilter();
});

function initIntegrationsFilter() {
  const filterContainer = document.querySelector(".integrations-filter");
  const filterForm = document.querySelector("#integration-filter-form");
  const filterItems = document.querySelectorAll(".category-filter");
  const allCheckbox = document.getElementById("filter-all");
  const integrationItems = document.querySelectorAll(".integration-item");

  if (!filterContainer || !filterForm) return;

  // Function to filter integration items
  function filterIntegrationItems() {
    // Find the checked category
    let selectedCategory = null;
    filterItems.forEach((cb) => {
      if (cb.checked) selectedCategory = cb.value;
    });

    // If "All" is selected or nothing is selected, show all
    if (!selectedCategory || selectedCategory === "all") {
      if (allCheckbox) allCheckbox.checked = true;
      integrationItems.forEach((item) => (item.style.display = ""));
      return;
    }

    // Otherwise, show only items matching the selected category
    integrationItems.forEach((item) => {
      item.style.display = item.classList.contains(selectedCategory)
        ? ""
        : "none";
    });
  }

  // Function to scroll active filter into view
  function scrollActiveFilterIntoView() {
    if (window.innerWidth <= 992) {
      const activeFilter = filterContainer.querySelector("input:checked");
      if (activeFilter) {
        const activeLabel = activeFilter.nextElementSibling;
        if (activeLabel) {
          const containerRect = filterForm.getBoundingClientRect();
          const labelRect = activeLabel.getBoundingClientRect();
          const scrollLeft = filterForm.scrollLeft;

          // Calculate if label is outside visible area
          const labelLeftRelative = labelRect.left - containerRect.left;
          const labelRightRelative = labelRect.right - containerRect.right;

          if (labelLeftRelative < 0) {
            // Label is cut off on the left
            filterForm.scrollLeft = scrollLeft + labelLeftRelative - 20;
          } else if (labelRightRelative > 0) {
            // Label is cut off on the right
            filterForm.scrollLeft = scrollLeft + labelRightRelative + 20;
          }
        }
      }
    }
  }

  // Add click event listeners to filter items
  filterItems.forEach((filter) => {
    filter.addEventListener("change", function () {
      // Uncheck all other checkboxes
      filterItems.forEach((other) => {
        if (other !== filter) other.checked = false;
      });

      // If none checked (user unchecks the only checked one), re-check "All"
      const anyChecked = Array.from(filterItems).some((c) => c.checked);
      if (!anyChecked && allCheckbox) allCheckbox.checked = true;

      // Filter the integration items
      filterIntegrationItems();

      // Small delay to ensure the filter state is updated before scrolling
      setTimeout(() => {
        scrollActiveFilterIntoView();
      }, 50);
    });
  });

  // Initialize draggable functionality for mobile
  if (filterForm) {
    let isDragging = false;
    let startX = 0;
    let scrollLeft = 0;

    // Mouse events
    filterForm.addEventListener("mousedown", (e) => {
      if (window.innerWidth <= 992) {
        isDragging = true;
        startX = e.pageX - filterForm.offsetLeft;
        scrollLeft = filterForm.scrollLeft;
        filterForm.style.cursor = "grabbing";
      }
    });

    filterForm.addEventListener("mouseleave", () => {
      if (window.innerWidth <= 992) {
        isDragging = false;
        filterForm.style.cursor = "grab";
      }
    });

    filterForm.addEventListener("mouseup", () => {
      if (window.innerWidth <= 992) {
        isDragging = false;
        filterForm.style.cursor = "grab";
      }
    });

    filterForm.addEventListener("mousemove", (e) => {
      if (window.innerWidth <= 992 && isDragging) {
        e.preventDefault();
        const x = e.pageX - filterForm.offsetLeft;
        const walk = (x - startX) * 2;
        filterForm.scrollLeft = scrollLeft - walk;
      }
    });

    // Touch events
    filterForm.addEventListener("touchstart", (e) => {
      if (window.innerWidth <= 992) {
        isDragging = true;
        startX = e.touches[0].pageX - filterForm.offsetLeft;
        scrollLeft = filterForm.scrollLeft;
      }
    });

    filterForm.addEventListener("touchmove", (e) => {
      if (window.innerWidth <= 992 && isDragging) {
        const x = e.touches[0].pageX - filterForm.offsetLeft;
        const walk = (x - startX) * 2;
        filterForm.scrollLeft = scrollLeft - walk;
      }
    });

    filterForm.addEventListener("touchend", () => {
      if (window.innerWidth <= 992) {
        isDragging = false;
      }
    });

    // Set cursor style on mobile
    function updateCursor() {
      if (window.innerWidth <= 992) {
        filterForm.style.cursor = "grab";
      } else {
        filterForm.style.cursor = "default";
      }
    }

    // Initial cursor setup
    updateCursor();

    // Update cursor on window resize
    window.addEventListener("resize", updateCursor);

    // Scroll active filter into view on window resize
    window.addEventListener("resize", () => {
      setTimeout(scrollActiveFilterIntoView, 100);
    });
  }

  // Initialize filter on page load
  filterIntegrationItems();

  // Initial scroll setup
  setTimeout(scrollActiveFilterIntoView, 100);
}

// Function to initialize accordions for a specific tab
function initializeAccordionsForTab(tab) {
  if (!tab) return;

  // Close all accordions in the tab first
  const allAccordions = tab.querySelectorAll(".accordion-item");
  allAccordions.forEach((accordion) => {
    const header = accordion.querySelector(".accordion-header");
    const content = accordion.querySelector(".accordion-content");
    const sign = accordion.querySelector(".accordion-sign");

    if (header && content && sign) {
      header.classList.remove("active");
      content.classList.remove("active");
      sign.textContent = "+";
    }
  });

  // Open the first accordion in the tab
  const firstAccordion = tab.querySelector(".accordion-item");
  if (firstAccordion) {
    const firstHeader = firstAccordion.querySelector(".accordion-header");
    const firstContent = firstAccordion.querySelector(".accordion-content");
    const firstSign = firstAccordion.querySelector(".accordion-sign");

    if (firstHeader && firstContent && firstSign) {
      firstHeader.classList.add("active");
      firstContent.classList.add("active");
      firstSign.textContent = "-";
    }
  }
}

// Make this function available globally
window.initializeAccordionsForTab = initializeAccordionsForTab;

// TABLE
document.addEventListener("DOMContentLoaded", function () {
  // Initialize the tab system only on mobile
  if (window.innerWidth < 992) {
    initializeTabs();
  }

  function resetToDesktop() {
    // Show all columns and remove mobile-specific styling
    document.querySelectorAll(".tab1 tr td").forEach((cell) => {
      cell.style.display = "table-cell";
    });

    document.querySelectorAll(".tabtv tr td").forEach((cell) => {
      cell.style.display = "table-cell";
    });

    // Remove all click event listeners
    document.querySelectorAll(".td-ch").forEach((tab) => {
      tab.replaceWith(tab.cloneNode(true));
    });
  }

  // Handle window resize
  window.addEventListener("resize", function () {
    if (window.innerWidth < 992) {
      initializeTabs();
    } else {
      resetToDesktop();
    }
  });

  function initializeTabs() {
    // Remove "Compare plans" text from first column
    const firstColumn = document.querySelector(".tab1 tr td:first-child");
    if (firstColumn) {
      firstColumn.style.display = "none";
    }

    // Set Pro tab as active by default (td-ch-2)
    const proTab = document.querySelector(".td-ch-2");
    if (proTab) {
      proTab.classList.add("td-active");
    }

    // Remove active class from other tabs
    document.querySelectorAll(".td-ch").forEach((tab) => {
      if (!tab.classList.contains("td-ch-2")) {
        tab.classList.remove("td-active");
      }
    });

    // Show only Pro tab content initially
    showActiveTabContent();

    // Add click event listeners to all tabs
    document.querySelectorAll(".td-ch").forEach((tab) => {
      tab.addEventListener("click", function () {
        // Remove active class from all tabs
        document
          .querySelectorAll(".td-ch")
          .forEach((t) => t.classList.remove("td-active"));

        // Add active class to clicked tab
        this.classList.add("td-active");

        // Show content for active tab only
        showActiveTabContent();
      });
    });
  }

  function showActiveTabContent() {
    // Get the active tab
    const activeTab = document.querySelector(".td-ch.td-active");
    if (!activeTab) return;

    // Get the column index of the active tab
    let activeIndex = 0;
    if (activeTab.classList.contains("td-ch-1")) activeIndex = 1;
    else if (activeTab.classList.contains("td-ch-2")) activeIndex = 2;
    else if (activeTab.classList.contains("td-ch-3")) activeIndex = 3;
    else if (activeTab.classList.contains("td-ch-4")) activeIndex = 4;

    // Hide all table content rows
    document.querySelectorAll(".tabtv tr").forEach((row) => {
      const cells = row.querySelectorAll("td");
      cells.forEach((cell, index) => {
        if (index === 0) {
          // Always show the first column (feature names)
          cell.style.display = "table-cell";
        } else if (index === activeIndex) {
          // Show only the active tab column
          cell.style.display = "table-cell";
        } else {
          // Hide other columns
          cell.style.display = "none";
        }
      });
    });

    // Handle header row - keep all tabs visible but hide "Compare plans"
    const headerRow = document.querySelector(".tab1 tr");
    if (headerRow) {
      const headerCells = headerRow.querySelectorAll("td");
      headerCells.forEach((cell, index) => {
        if (index === 0) {
          // Hide "Compare plans" column
          cell.style.display = "none";
        } else {
          // Show all tab headers so users can click them
          cell.style.display = "table-cell";
        }
      });
    }
  }

  // Optional: Add some smooth transitions
  const style = document.createElement("style");
  style.textContent = `
      .td-ch {
          cursor: pointer;
          transition: all 0.3s ease;
      }
      
      .td-ch.td-active {
          background-color: #f0f8ff;
          border-color: #007cba;
      }
      
      .td-ch:hover {
          background-color: #f9f9f9;
      }
      
      .tabtv td {
          transition: opacity 0.2s ease;
      }
      
      /* Mobile responsive adjustments */
      @media (max-width: 991px) {
          .tab1 {
              width: 100%;
              table-layout: fixed;
          }
          
          .td-ch {
              width: 100%;
              text-align: center;
              padding: 12px 8px;
          }
          
          .tabtv {
              width: 100%;
          }
          
          .tabtv td:first-child {
              width: 60%;
              text-align: left;
          }
          
          .tabtv td:not(:first-child) {
              width: 40%;
              text-align: center;
          }
      }
  `;
  document.head.appendChild(style);
});
